<?php
/**
 * MPS ADMIN - Admin Meta Boxes, Validation, Cron Jobs
 * Requires: MPS Core
 */

if (!defined('ABSPATH')) exit;

// ===========================================================================
// ADMIN META BOX FOR SITTER DETAILS
// ===========================================================================

add_action('add_meta_boxes', function() {
    add_meta_box('mps_sitter_meta', 'Sitter Details', 'mps_sitter_meta_box', 'sitter', 'normal', 'high');
});

function mps_sitter_meta_box($post) {
    wp_nonce_field('mps_sitter_meta', 'mps_sitter_meta_nonce');
    $meta = mps_get_sitter_meta($post->ID);
    $services_map = mps_services_map();
    ?>
    <style>
        .mps-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .mps-service-row { display: flex; align-items: center; gap: 12px; padding: 8px; background: #f9f9f9; margin-bottom: 4px; border-radius: 4px; }
        .mps-service-row label { flex: 1; display: flex; align-items: center; gap: 8px; }
        .mps-service-row input[type="number"] { width: 80px; }
    </style>
    <div class="mps-grid">
        <p><label>City<br>
            <select name="mps_city" style="width:100%">
                <option value="">Select...</option>
                <?php foreach (mps_cities_list() as $c): ?>
                    <option <?php selected($meta['city'], $c); ?>><?= esc_html($c) ?></option>
                <?php endforeach; ?>
            </select>
        </label></p>
        <p><label>Suburb<br><input type="text" name="mps_suburb" value="<?= esc_attr($meta['suburb']) ?>" style="width:100%"></label></p>
        <p><label>Email<br><input type="email" name="mps_email" value="<?= esc_attr($meta['email']) ?>" style="width:100%"></label></p>
        <p><label>Phone<br><input type="text" name="mps_phone" value="<?= esc_attr($meta['phone']) ?>" style="width:100%"></label></p>
    </div>
    
    <h4 style="margin: 16px 0 8px;">Services & Pricing</h4>
    <p style="color: #666; margin-bottom: 12px;">Check services offered and set starting prices ($/session).</p>
    
    <?php foreach ($services_map as $svc => $slug): 
        $is_checked = in_array($svc, $meta['services']);
        $price_key = 'mps_price_' . sanitize_title($svc);
        $price = get_post_meta($post->ID, $price_key, true);
    ?>
    <div class="mps-service-row">
        <label>
            <input type="checkbox" name="mps_services[]" value="<?= esc_attr($svc) ?>" <?php checked($is_checked); ?>>
            <strong><?= esc_html($svc) ?></strong>
        </label>
        <span>$</span>
        <input type="number" name="price_<?= sanitize_title($svc) ?>" value="<?= esc_attr($price) ?>" placeholder="0" min="0" step="1">
    </div>
    <?php endforeach; ?>
    <?php
}

// ===========================================================================
// SAVE META + SYNC TAXONOMIES
// ===========================================================================

add_action('save_post_sitter', function($post_id) {
    if (!isset($_POST['mps_sitter_meta_nonce']) || !wp_verify_nonce($_POST['mps_sitter_meta_nonce'], 'mps_sitter_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    
    $city = sanitize_text_field($_POST['mps_city'] ?? '');
    $suburb = sanitize_text_field($_POST['mps_suburb'] ?? '');
    $email = sanitize_email($_POST['mps_email'] ?? '');
    $phone = sanitize_text_field($_POST['mps_phone'] ?? '');
    $services = isset($_POST['mps_services']) ? mps_normalise_services_labels($_POST['mps_services']) : [];
    
    update_post_meta($post_id, 'mps_city', $city);
    update_post_meta($post_id, 'mps_suburb', $suburb);
    update_post_meta($post_id, 'mps_email', $email);
    update_post_meta($post_id, 'mps_phone', $phone);
    update_post_meta($post_id, 'mps_services', implode(', ', $services));
    
    // Save per-service prices
    $services_map = mps_services_map();
    foreach (array_keys($services_map) as $svc) {
        $key = 'price_' . sanitize_title($svc);
        $price = sanitize_text_field($_POST[$key] ?? '');
        update_post_meta($post_id, 'mps_price_' . sanitize_title($svc), $price);
    }
    
    // Sync city taxonomy
    if ($city && taxonomy_exists('mps_city')) {
        $term = term_exists($city, 'mps_city');
        if (!$term) $term = wp_insert_term($city, 'mps_city', ['slug' => mps_slugify($city)]);
        if (!is_wp_error($term)) wp_set_object_terms($post_id, (int)($term['term_id'] ?? $term), 'mps_city', false);
    } else {
        wp_set_object_terms($post_id, [], 'mps_city', false);
    }
    
    // Sync service taxonomy
    if (taxonomy_exists('mps_service')) {
        $ids = [];
        foreach ($services as $label) {
            $slug = mps_services_map()[$label] ?? mps_slugify($label);
            $t = term_exists($label, 'mps_service');
            if (!$t) $t = wp_insert_term($label, 'mps_service', ['slug' => $slug]);
            if (!is_wp_error($t)) $ids[] = (int)($t['term_id'] ?? $t);
        }
        wp_set_object_terms($post_id, $ids, 'mps_service', false);
    }
}, 10);

// ===========================================================================
// ADMIN COLUMNS
// ===========================================================================

add_filter('manage_sitter_posts_columns', function($cols) {
    $cols['mps_city'] = 'City';
    $cols['mps_services'] = 'Services';
    return $cols;
});

add_action('manage_sitter_posts_custom_column', function($col, $post_id) {
    if ($col === 'mps_city') echo esc_html(get_post_meta($post_id, 'mps_city', true));
    if ($col === 'mps_services') echo esc_html(get_post_meta($post_id, 'mps_services', true));
}, 10, 2);

// ===========================================================================
// GUARD PUBLISH (require city + service)
// ===========================================================================

add_action('transition_post_status', function($new, $old, $post) {
    if ($post->post_type !== 'sitter') return;
    if ($old === 'publish' && $new === 'publish') return;
    if ($new !== 'publish') return;
    
    $city = trim(get_post_meta($post->ID, 'mps_city', true));
    $svc = array_filter(explode(',', get_post_meta($post->ID, 'mps_services', true)));
    
    if (!$city || !$svc) {
        remove_action('transition_post_status', __FUNCTION__, 10);
        wp_update_post(['ID' => $post->ID, 'post_status' => 'pending']);
        add_action('transition_post_status', __FUNCTION__, 10, 3);
        
        if (defined('MPS_ADMIN_EMAIL')) {
            wp_mail(MPS_ADMIN_EMAIL, 'Sitter incomplete: moved to pending',
                "Sitter #{$post->ID} missing " . (!$city ? 'city' : 'services') . "\n" . admin_url("post.php?post={$post->ID}&action=edit"));
        }
    }
}, 10, 3);

// ===========================================================================
// NIGHTLY RESYNC CRON
// ===========================================================================

add_action('init', function() {
    if (!wp_next_scheduled('mps_nightly_resync')) {
        wp_schedule_event(time() + 60, 'daily', 'mps_nightly_resync');
    }
});

add_action('mps_nightly_resync', function() {
    $q = new WP_Query(['post_type' => 'sitter', 'post_status' => ['publish','pending','draft'], 'posts_per_page' => 500, 'fields' => 'ids']);
    
    foreach ($q->posts as $id) {
        $city = get_post_meta($id, 'mps_city', true);
        if ($city && taxonomy_exists('mps_city')) {
            $t = term_exists($city, 'mps_city');
            if (!$t) $t = wp_insert_term($city, 'mps_city', ['slug' => mps_slugify($city)]);
            if (!is_wp_error($t)) wp_set_object_terms($id, (int)($t['term_id'] ?? $t), 'mps_city', false);
        }
        
        $terms = wp_get_object_terms($id, 'mps_service', ['fields' => 'all']);
        if (!is_wp_error($terms) && $terms) {
            $labels = array_map(fn($t) => mps_service_slug_to_label($t->slug), $terms);
            $csv = implode(', ', array_unique($labels));
            if ($csv !== get_post_meta($id, 'mps_services', true)) {
                update_post_meta($id, 'mps_services', $csv);
            }
        }
    }
});

add_action('switch_theme', function() {
    $ts = wp_next_scheduled('mps_nightly_resync');
    if ($ts) wp_unschedule_event($ts, 'mps_nightly_resync');
});

// ===========================================================================
// SITTER TITLE FALLBACK
// ===========================================================================

add_action('save_post_sitter', function($post_id, $post, $update) {
    if ($update) return;
    $title = get_the_title($post_id);
    if (!$title || $title === 'Auto Draft') {
        $name = get_post_meta($post_id, 'mps_name', true);
        $city = get_post_meta($post_id, 'mps_city', true);
        $fallback = implode(' - ', array_filter([$name, $city])) ?: 'New Sitter';
        wp_update_post(['ID' => $post_id, 'post_title' => $fallback, 'post_name' => sanitize_title($fallback)]);
    }
}, 20, 3);

// ===========================================================================
// ADMIN: FIX "VIEW" LINK IN USER LIST
// ===========================================================================

add_filter('user_row_actions', function($actions, $user_object) {
    if (!isset($actions['view'])) return $actions;

    // Check if user is a Sitter
    $sitter_post = get_posts([
        'post_type'   => 'sitter',
        'author'      => $user_object->ID,
        'numberposts' => 1,
        'post_status' => ['publish', 'pending', 'draft']
    ]);

    if (!empty($sitter_post)) {
        // Link to their Sitter Profile (frontend)
        $actions['view'] = '<a href="' . get_permalink($sitter_post[0]->ID) . '" aria-label="View Sitter Profile">View Profile</a>';
    } else {
        // For Owners/Others, remove View link if it just goes to a broken Author Archive
        // Or keep it if you want to see their (non-existent) posts?
        // User asked to "view accounts", likely meaning their public face.
        // Owners don't have a public face. Let's remove it to avoid confusion/redirect to home.
        unset($actions['view']);
    }
    
    return $actions;
}, 10, 2);

// ===========================================================================
// ADMIN: SHOW OWNER & PET DATA IN USER PROFILE
// ===========================================================================

add_action('show_user_profile', 'mps_show_extra_profile_fields');
add_action('edit_user_profile', 'mps_show_extra_profile_fields');

function mps_show_extra_profile_fields($user) {
    // 1. Owner Details
    $phone = get_user_meta($user->ID, 'mps_phone', true);
    $address = get_user_meta($user->ID, 'mps_address', true);
    
    // 2. Fetch Pets
    $pets = get_posts([
        'post_type'   => 'mps_pet',
        'author'      => $user->ID,
        'numberposts' => -1,
        'post_status' => 'any'
    ]);
    
    ?>
    <h2 style="margin-top:40px;border-top:1px solid #ddd;padding-top:20px;">My Pet Sitters Data</h2>
    
    <table class="form-table" role="presentation">
        <!-- Actions -->
        <tr>
            <th>Actions</th>
            <td>
                <a href="<?= home_url('/account/?view_user_id=' . $user->ID) ?>" class="button button-secondary" target="_blank">👁️ View Dashboard as User</a>
                <p class="description">Opens the frontend "My Account" page as this user.</p>
            </td>
        </tr>
        <!-- Contact Info -->
        <tr>
            <th><label for="mps_phone">Phone Number</label></th>
            <td>
                <input type="text" name="mps_phone" id="mps_phone" value="<?= esc_attr($phone) ?>" class="regular-text" />
            </td>
        </tr>
        <tr>
            <th><label for="mps_address">Address / Suburb</label></th>
            <td>
                <input type="text" name="mps_address" id="mps_address" value="<?= esc_attr($address) ?>" class="regular-text" />
            </td>
        </tr>
        
        <!-- Pets Grid -->
        <tr>
            <th>User's Pets</th>
            <td>
                <?php if ($pets): ?>
                    <style>
                        .mps-admin-pet-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 16px; max-width: 800px; }
                        .mps-admin-pet-card { border: 1px solid #ccc; background: #fff; padding: 10px; border-radius: 8px; text-align: center; }
                        .mps-admin-pet-img { width: 100%; height: 100px; object-fit: cover; border-radius: 4px; background: #eee; margin-bottom: 8px; }
                    </style>
                    <div class="mps-admin-pet-grid">
                        <?php foreach ($pets as $pet): 
                            $img = get_the_post_thumbnail_url($pet->ID, 'thumbnail');
                            $breed = get_post_meta($pet->ID, 'mps_pet_breed', true);
                            $age = get_post_meta($pet->ID, 'mps_pet_age', true);
                        ?>
                        <div class="mps-admin-pet-card">
                            <?php if ($img): ?>
                                <img src="<?= esc_url($img) ?>" class="mps-admin-pet-img">
                            <?php else: ?>
                                <div class="mps-admin-pet-img" style="display:flex;align-items:center;justify-content:center;color:#999;font-size:30px;">🐾</div>
                            <?php endif; ?>
                            
                            <strong><?= esc_html($pet->post_title) ?></strong><br>
                            <span style="font-size:12px;color:#666;"><?= esc_html($breed) ?> (<?= esc_html($age) ?>)</span>
                            
                            <!-- If you wanted to link to edit the pet CPT directly (if UI allowed): -->
                             <!-- <br><a href="<?= get_edit_post_link($pet->ID) ?>">Edit Pet</a> -->
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="description">No pets listed for this user.</p>
                <?php endif; ?>
            </td>
        </tr>
    </table>
    <?php
}

// ===========================================================================
// AUTO-FIX: ENSURE SITTERS HAVE 'SITTER' ROLE
// ===========================================================================
add_action('admin_init', function() {
    // Run only for admins
    if (!current_user_can('manage_options')) return;
    
    // 1. Get all published sitters
    $sitters = get_posts(['post_type'=>'sitter', 'post_status'=>'any', 'posts_per_page'=>-1]);
    
    foreach ($sitters as $post) {
        $user_id = $post->post_author;
        if ($user_id) {
            $u = get_userdata($user_id);
            if ($u && !in_array('sitter', (array)$u->roles) && !in_array('administrator', (array)$u->roles)) {
                $u->add_role('sitter');
                // Optional: Log it somewhere or just do it silently
            }
        }
    }
});

// Save Admin Edits (Phone/Address)
add_action('personal_options_update', 'mps_save_extra_profile_fields');
add_action('edit_user_profile_update', 'mps_save_extra_profile_fields');

function mps_save_extra_profile_fields($user_id) {
    if (!current_user_can('edit_user', $user_id)) return false;
    
    if (isset($_POST['mps_phone'])) 
        update_user_meta($user_id, 'mps_phone', sanitize_text_field($_POST['mps_phone']));
        
    if (isset($_POST['mps_address'])) 
        update_user_meta($user_id, 'mps_address', sanitize_text_field($_POST['mps_address']));
}
